<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <?php echo $__env->yieldContent('stylefirst'); ?>
    <link rel="stylesheet" href="/assets/css/main/app.css">
    <link rel="stylesheet" href="/assets/css/main/app-dark.css">
    <link rel="shortcut icon" href="/assets/images/logo/favicon.ico" type="image/x-icon">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <div id="app">
        <div id="sidebar" class="active">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div id="main" class="layout-navbar navbar-fixed">
            <header class="mb-3">
                <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </header>
            <div id="main-content">
                <?php echo $__env->yieldContent('content'); ?>
                <footer>
                    <div class="footer clearfix mb-0 text-muted">
                        <div class="float-end">
                            <p><?php echo date('Y'); ?> &copy; We Care</p>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <script src="/assets/js/initTheme.js"></script>
    <script src="/assets/js/bootstrap.js"></script>
    <script src="/assets/js/app.js"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH E:\Coding\We-Care\resources\views/layouts/master.blade.php ENDPATH**/ ?>