
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
        integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/assets/css/main/blog.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <header class="masthead"
        style="background:linear-gradient(-45deg,#36d1dc,#5b86e5,#ee7752,#e73c7e,#23a6d5,#23d5ab);background-size:400% 400%;-webkit-animation:Gradient 15s ease infinite;-moz-animation:Gradient 15s ease infinite;animation:Gradient 15s ease infinite;top:0;left:0;right:0;width:100%;z-index:999;height:48px;">
        <div class="container position-relative px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <div class="post-heading text-center">
                        <h1>Blog</h1>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <main class="my-5">
        <div class="container">
            <section class="text-center">

                <div class="row">
                    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-12 mb-4">
                            <div class="card">
                                <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light">
                                    <img src="<?php echo e(asset('/storage/images/thumbnail/' . $item->gambar_blog)); ?>"
                                        class="img-fluid" />
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a href="/blog/<?php echo e($item->slug_blog); ?>"
                                            style="color: #212529; text-decoration: none;"><?php echo e($item->judul_blog); ?></a>
                                    </h5>
                                    <p class="card-text">
                                        <?php echo Str::limit($item->isi_blog, 100); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <nav class="my-4" aria-label="...">
                    <ul class="pagination pagination-circle justify-content-center">
                        <?php echo e($blog->links()); ?>

                    </ul>
                </nav>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\We-Care\resources\views/landing/blog.blade.php ENDPATH**/ ?>