<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>We Care</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/splide.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/hover.css')); ?>">
  <style>
    .item{
      display: block;
    }
    /* Menyembunyikan navbar di tampilan desktop */
  @media (min-width: 768px) {
  .dekstop{
    display: block;
  }
  .mobile{
    display: none;
  }
}

  /* Menampilkan navbar di tampilan mobile */
  @media (max-width: 767px) {
  .dekstop{
    display: none;
  }
  .mobile{
    display: block;
  }
}

.container-input {
  position: relative;
}

.input {
  width: 150px;
  padding: 10px 0px 10px 40px;
  border-radius: 9999px;
  border: solid 1px #2B7A77;
  transition: all .2s ease-in-out;
  outline: none;
  opacity: 1;
}

.container-input svg {
  position: absolute;
  top: 50%;
  left: 10px;
  transform: translate(0, -50%);
}

.input:focus {
  opacity: 1;
  width: 250px;
}

  </style>
</head>
<body style="font-family: poppins; background-color:#F8F9FA;" id="body">

  <section class="shadow-sm fixed-top" id="searchbar">
    <nav class="row navbar p-3 mobile" style="background-color:#3AAFA9;">
    <div class="container justify-content-center">
      <form class="d-flex" role="search">
        <div class="container-input">
          <input type="text" placeholder="Pencarian" name="text" class="input" aria-label="Search" id="searchbox">
          <svg fill="#000000" width="20px" height="20px" viewBox="0 0 1920 1920" xmlns="http://www.w3.org/2000/svg">
            <path d="M790.588 1468.235c-373.722 0-677.647-303.924-677.647-677.647 0-373.722 303.925-677.647 677.647-677.647 373.723 0 677.647 303.925 677.647 677.647 0 373.723-303.924 677.647-677.647 677.647Zm596.781-160.715c120.396-138.692 193.807-319.285 193.807-516.932C1581.176 354.748 1226.428 0 790.588 0S0 354.748 0 790.588s354.748 790.588 790.588 790.588c197.647 0 378.24-73.411 516.932-193.807l516.028 516.142 79.963-79.963-516.142-516.028Z" fill-rule="evenodd"></path>
        </svg>
        </div>
      </form>
    </div>
    </nav>

    
    <nav class="navbar dekstop" style="background-color:#3AAFA9;">
      <div class="container p-1">
        <a href="" class="navbar-brand" style="color: #ffffff;"><h2>WeCare</h2></a>
        <a href="" class="nav-item px-2" style="color: #ffffff;text-decoration: none;">Donasi Saya</a>
        <?php if(auth()->guard()->check()): ?>
        <div class="nav-item px-2">
          <a style="color:#ffffff" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo e(Auth::user()->name); ?>

          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li> <form class="px-2" action="/logout" method="post">
              <?php echo csrf_field(); ?>
              <button class="btn" type="submit" href="/logout" style="background-color:none; border-radius:50px; color:#2B7A77; padding:8px">
              Logout
              </button>
          </form></li>
          </ul>
        </div>
                          <form class="px-2" action="/logout" method="post">
          <?php echo csrf_field(); ?>
          <button class="btn" type="submit" href="/logout" style="background-color:#ffffff; border-radius:50px; color:#2B7A77">
          Logout
          </button>
      </form>
        <?php else: ?>
        <a href="/login" class="nav-item px-2" style="color: #ffffff;text-decoration: none;">Login</a>
        <?php endif; ?>
        <form class="ms-auto d-flex" role="search">
          <div class="container-input">
            <input type="text" placeholder="Pencarian" name="text" class="input" aria-label="Search" id="searchbox2">
            <svg fill="#000000" width="20px" height="20px" viewBox="0 0 1920 1920" xmlns="http://www.w3.org/2000/svg">
              <path d="M790.588 1468.235c-373.722 0-677.647-303.924-677.647-677.647 0-373.722 303.925-677.647 677.647-677.647 373.723 0 677.647 303.925 677.647 677.647 0 373.723-303.924 677.647-677.647 677.647Zm596.781-160.715c120.396-138.692 193.807-319.285 193.807-516.932C1581.176 354.748 1226.428 0 790.588 0S0 354.748 0 790.588s354.748 790.588 790.588 790.588c197.647 0 378.24-73.411 516.932-193.807l516.028 516.142 79.963-79.963-516.142-516.028Z" fill-rule="evenodd"></path>
          </svg>
          </div>
        </form>
      </div>
    </nav>

  </section>

  <nav class="fixed-bottom mb-4 mobile">
    <div class="container-fluid" style="width: 100%;">
        <div class="container d-flex align-items-center justify-content-center shadow" style="background-image: linear-gradient(to bottom right, #2B7A77, #3AAFA9); height:75px; border-radius:750px; width: 97%; border: solid #ffffff 5px; margin: 0px; padding: 0px;">

            <div class="row">

                <div class="col mx-3">
                    <a href="mailto:bemfv.unair@email.com"><img src="assets/img/home-icon-pink.png"  alt=""  id="chat" style="height: 50px"></a>
                </div>

                <div class="col mx-3">
                    <a href=""><img src="assets/img/home-icon-pink.png" alt="" style="height: 50px"></a>
                </div>
                <div class="col mx-3">
                    <a href="" <?php if(auth()->guard()->check()): ?> data-bs-toggle="modal" data-bs-target="#profile" <?php else: ?> data-bs-toggle="modal" data-bs-target="#pesan" <?php endif; ?>><img src="assets/img/ava-icon-white.png" alt="" style="height: 50px"></a>
                </div>
            </div>

        </div>
    </div>
</nav>

  <section id="item" style="background-color: rgb(255, 255, 255); border-radius: 20px;" class="item my-3 " data-filter="item">
    <div class="container p-4">
      <div style="height:60px"></div>
      <h3 style="font-weight:bold; color: #2B7A77;">Selamat Datang !</h3>
      <a href="" data-bs-toggle="modal" data-bs-target="#createcampaign" style="text-decoration: none;">
          <div class="hvr-grow shadow mt-3 d-flex align-items-center" style="height: 250px; border-radius:25px; background-image: linear-gradient(to right, #2B7A77, rgba(231, 231, 231, 0.5)), url('https://images.unsplash.com/photo-1615897570582-285ffe259530?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'); background-size: cover;">
              <div class="p-4" style="max-width:80%">
                  <h1 style="font-weight: inherit; color:#ffffff; font-size:35px;">Galang Dana Sekarang</h1>
              </div>
          </div>
      </a>
  </div>

<!-- modal -->
<div class="modal fade" id="createcampaign" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <?php if(auth()->guard()->check()): ?>
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Tatacara Galang Dana</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#create">Selanjutnya</button>
      </div>
    </div>
    <?php else: ?>
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Anda perlu login</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <a class="btn" style="border-radius: 50px; background-color:#2B7A77; color:#ffffff" href="/login">Login</a>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php if(auth()->guard()->check()): ?>
<div class="modal fade" id="create" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" class="row g-3" action="/createCampaign"enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="row">
              <form class="row g-3">
                  <div class="col-md-6">
                      <label class="form-label">Email</label>
                      <input type="text" class="form-control" disabled value="<?php echo e(Auth::user()->email); ?>">
                  </div>
                  <div class="col-md-6">
                      <label class="form-label">Nama</label>
                      <input disabled type="text" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
                      <input name="user_id" type="hidden" class="form-control" value="<?php echo e(Auth::user()->id); ?>" required>
                  </div>
          </div>
          <div class="mb-3">
              <label class="form-label">Kategori Campaign</label>
              <select name="category_id" class="form-select" aria-label="Default select example">
                  <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_kategori); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="mb-3 mt-3">
              <label class="form-label">Judul Campaign</label>
              <input name="judul_campaign" type="text" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Deskripsi Campaign</label>
              <textarea name="deskripsi_campaign" type="text" class="form-control" cols="30" rows="10" required></textarea>
          </div>
          <div class="mb-3 mt-3">
              <label class="form-label">Target Dana</label>
              <input name="target_campaign" type="number" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Tanggal Akhir Campaign</label>
              <input name="tgl_akhir" type="date" class="form-control" required>
          </div>
          <div class="form-group mt-2">
              <strong>Banner Campaign</strong>
              <input class="form-control" type="file" name="image" id="formFile" required>
          </div>
          <button type="submit" class="btn btn-success">Submit</button>
      </form>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

  </section>

  <section data-filter="item" id="item" style="background-color: rgb(255, 255, 255); border-radius: 20px;" class="item my-3 py-3">
    <div class="container text-center">
      <div class="row p-4" style="font-size:medium">
          <button id="button_pendidikan" value="2" class="col hvr-grow" style="background-color: white; border: none;">
              <img src="assets/img/education.png" alt="" style="height: 90px">
              <div class="d-flex align-items-center justify-content-center">
                <p style="margin: 0px;">Pendidikan</p>
              </div>
            </button>
          <button id="button_sosial" value="1" class="col hvr-grow" style="background-color: white; border: none;">
              <img src="assets/img/social.png" alt="" style="height: 90px">
              <div class="d-flex align-items-center justify-content-center">
                <p style="margin: 0px;">Sosial</p>
              </div>
            </button>
          <button id="button_kesehatan" value="3" class="col hvr-grow" style="background-color: white; border: none;">
              <img src="assets/img/health.png" alt="" style="height: 90px">
              <div class="d-flex align-items-center justify-content-center">
                <p style="margin: 0px;">Kesehatan</p>
              </div>
            </button>
      </div>
  </div>
  </section>

  <section data-filter="item" class="item splide my-3" aria-labelledby="carousel-heading" id="item" style="background-color: rgb(253, 253, 253); border-radius: 20px;">
    <div class="container p-4">
      <div class="col" style="width: 75%;">
        <h5 class="p-2" style="font-weight:bold; color: #2B7A77;">Penggalangan Dana Mendesak</h5>
      </div>
      <div class="splide__track">
        <ul class="splide__list">
          <?php $__currentLoopData = $campaign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="campaign/<?php echo e($item->id); ?>" class="splide__slide d-flex justify-content-center px-2 py-1" style="text-decoration: none; color:black">
            <div class="card hvr-grow" style="width: auto;  border-color: #2B7A77;">
              <img src="storage/<?php echo e($item->foto_campaign); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <div class="card-title">
                  <h5><?php echo e($item->judul_campaign); ?></h5>
                </div>
                <div class="progress" style="height: 10px;">
                  <div class="progress-bar w-75" role="progressbar" aria-label="Basic example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="background-color:#3AAFA9"></div>
                </div>
                <p class="card-text mt-2">Donasi terkumpul : $999</p>
                <p class="card-text">Aktif hingga : 17 Agustus 1945 </p>
              </div>
            </div>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
  </section>

   <section data-filter="item" id="item" style="background-color: rgb(255, 255, 255); border-radius: 20px;" class="item my-3 py-3">
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
      </div>
      <div class="container p-4">
        <div class="carousel-inner" style="border-radius: 8px;">
          <div class="carousel-item active">
            <img src="https://images.unsplash.com/photo-1581059686229-de26e6ae5dc4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1172&q=80" class="d-block w-100" alt="..." style="height: 30vh; object-fit: cover">
            <div class="carousel-caption d-none d-md-block">
              <h5>Aksi Penyaluran Dana Bantuan Tsunami</h5>
              <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt, deserunt.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://images.unsplash.com/photo-1475776408506-9a5371e7a068?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1058&q=80" class="d-block w-100" alt="..." style="height: 30vh; object-fit: cover">
            <div class="carousel-caption d-none d-md-block">
              <h5>Penyaluran Dana Bantuan Korban Erupsi Semeru</h5>
              <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minima, aliquid.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://images.unsplash.com/photo-1544257750-572358f5da22?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1215&q=80" class="d-block w-100" alt="..." style="height: 30vh; object-fit: cover">
            <div class="carousel-caption d-none d-md-block">
              <h5>Penyaluran Dana Bantuan Korban Terdampak Badai</h5>
              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolor, molestias!</p>
            </div>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </section>

  <section data-filter="item" id="item" style="background-color: rgb(255, 255, 255); border-radius: 20px;" class="item my-3 py-3">
    <div class="container p-4">
    <div class="col" style="width: 75%;">
      <h5 class="p-2" style="font-weight:bold; color: #2B7A77;">Artikel Terbaru</h5>
    </div>
    <div class="card-group">
      <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card" style="border-color: #2B7A77;">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($item->judul_blog); ?></h5>
          <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus repellat eos voluptatibus cum quos odit rem architecto molestias quae. Consectetur.</p>
          <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div style="height:60px"></div>
  </div>
  </section>

  
  <section id="result" class="d-none" style=" background-color: rgb(255, 255, 255); border-radius: 20px;">
    <div style="height:60px"></div>
    <div class="container text-center">
      <h5 class="p-4 mt-2" style="font-weight:bold; color: #2B7A77;">Hasil Pencarian</h5>
      <button class="btn" style="border-radius: 50px; background-color:#2B7A77"><a style="color: #ffffff; text-decoration:none" href="/">
        <svg height="16" width="16" xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 1024 1024"><path d="M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z" fill="#ffffff"></path></svg>
        <span >Kembali</span></a>
      </button>
    </div>
    <div class="row justify-content-center p-4">
      <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="campaign/<?php echo e($item->id); ?>" class="item card hvr-grow m-2" data-filter="<?php echo e($item->judul_campaign); ?>" style="width: 18rem; padding: 0px;  border-color: #2B7A77; text-decoration: none; color:black" >
      <img src="storage/<?php echo e($item->foto_campaign); ?>" class="card-img-top" alt="...">
      <div class="card-body">
        <div class="card-title">
          <h5><?php echo e($item->judul_campaign); ?></h5>
        </div>
        <div class="progress" style="height: 10px;">
          <div class="progress-bar w-75" role="progressbar" aria-label="Basic example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="background-color:#3AAFA9"></div>
        </div>
        <p class="card-text mt-2">Donasi terkumpul : $999</p>
        <p class="card-text">Aktif hingga : 17 Agustus 1945 </p>
      </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- dikeep 1 div kosongan buat tumbalnya kalo g gitu gamau kebaca yg paling bawah -->
    <div class="item card" data-filter="tumbal" style="width: 18rem; padding: 0px;">
      <img src="https://images.unsplash.com/photo-1599059813005-11265ba4b4ce?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80" class="card-img-top" alt="...">
      <div class="card-body">
        <p class="card-text">contoh search filter yang tes Lorem ipsum dolor, sit amet consectetur adipisicing elit. Autem, dolor.</p>
      </div>
    </div>
    <div style="height:100px"></div>
  </div>
  </section>

  
  <section id="category" class="d-none" style=" background-color: rgb(255, 255, 255); border-radius: 20px;">
    <div style="height:60px"></div>
    <div class="container text-center">
      <h5 class="p-4 mt-2" style="font-weight:bold; color: #2B7A77;">Hasil Pencarian</h5>
            <button class="btn" style="border-radius: 50px; background-color:#2B7A77"><a style="color: #ffffff; text-decoration:none" href="/">
        <svg height="16" width="16" xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 1024 1024"><path d="M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z" fill="#ffffff"></path></svg>
        <span >Kembali</span></a>
      </button>
    </div>
    <div class="row justify-content-center p-4">
      <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="campaign/<?php echo e($item->id); ?>" class="item card hvr-grow m-2" data-filter="<?php echo e($item->category_id); ?>" style="width: 18rem; padding: 0px;  border-color: #2B7A77; text-decoration: none; color:black">
        <img src="storage/<?php echo e($item->foto_campaign); ?>" class="card-img-top" alt="...">
        <div class="card-body">
          <div class="card-title">
            <h5><?php echo e($item->judul_campaign); ?></h5>
          </div>
          <div class="progress" style="height: 10px;">
            <div class="progress-bar w-75" role="progressbar" aria-label="Basic example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="background-color:#3AAFA9"></div>
          </div>
          <p class="card-text mt-2">Donasi terkumpul : $999</p>
          <p class="card-text">Aktif hingga : 17 Agustus 1945 </p>
        </div>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- dikeep 1 div kosongan buat tumbalnya kalo g gitu gamau kebaca yg paling bawah -->
    <div class="item card" data-filter="tumbal" style="width: 18rem; padding: 0px;">
      <img src="https://images.unsplash.com/photo-1599059813005-11265ba4b4ce?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80" class="card-img-top" alt="...">
      <div class="card-body">
        <p class="card-text">contoh search filter yang tes Lorem ipsum dolor, sit amet consectetur adipisicing elit. Autem, dolor.</p>
      </div>
    </div>
    <div style="height:100px"></div>
  </div>
  </section>


  <script src="<?php echo e(asset('js/splide.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
  <script>
    var splide = new Splide( '.splide', {
  perPage: window.innerWidth <= 480 ? 1 : 3, // menampilkan 1 slide pada tampilan mobile
  rewind : true,
} );

// tambahkan event listener untuk memeriksa perubahan lebar layar dan menyesuaikan jumlah slide yang ditampilkan
window.addEventListener( 'resize', function () {
  splide.options.perPage = window.innerWidth <= 480 ? 1 : 3;
  splide.destroy( false );
  splide.mount();
} );

splide.mount();

  </script>

  <script>
    const search = document.getElementById('searchbox');
    const body = document.getElementById('body');
    const resultspace = document.getElementById('result');
    const categoryspace = document.getElementById('category');
    const items = body.querySelectorAll('.item');

  search.addEventListener('input', function() {
  const filter = this.value.toLowerCase();
  items.forEach(function(item) {
    const filterData = item.getAttribute('data-filter').toLowerCase();
    if (filterData.includes(filter)) {
      item.style.display = 'block';
      resultspace.classList.add("d-none");
      categoryspace.classList.add("d-none");
    } else {
      item.style.display = 'none';
      resultspace.classList.remove("d-none");
      categoryspace.classList.add("d-none");
    }
  });

}); //end event listener
  </script>

<script>
  const search2 = document.getElementById('searchbox2');
search2.addEventListener('input', function() {
const filter = this.value.toLowerCase();
items.forEach(function(item) {
  const filterData = item.getAttribute('data-filter').toLowerCase();
  if (filterData.includes(filter)) {
    item.style.display = 'block';
    resultspace.classList.add("d-none");
    categoryspace.classList.add("d-none");
    // categoryspace.classList.add("d-none");
  } else {
    item.style.display = 'none';
    resultspace.classList.remove("d-none");
    categoryspace.classList.add("d-none");
    // categoryspace.classList.remove("d-none");
  }
});

}); //end event listener
</script>

<!-- filter kesehatan -->
<script>
  const kesehatan = document.getElementById('button_kesehatan');

kesehatan.addEventListener('click', function() {
const filter_category = this.value.toLowerCase();
items.forEach(function(item) {
  const filterData = item.getAttribute('data-filter').toLowerCase();
  if (filterData.includes(filter_category)) {
    item.style.display = 'block';
    categoryspace.classList.add("d-none");
  } else {
    item.style.display = 'none';
    categoryspace.classList.remove("d-none");
  }
});

}); //end event listener
</script>

<!-- filter pendidikan -->
<script>
  const pendidikan = document.getElementById('button_pendidikan');

pendidikan.addEventListener('click', function() {
const filter_category = this.value.toLowerCase();
items.forEach(function(item) {
  const filterData = item.getAttribute('data-filter').toLowerCase();
  if (filterData.includes(filter_category)) {
    item.style.display = 'block';
    categoryspace.classList.add("d-none");
  } else {
    item.style.display = 'none';
    categoryspace.classList.remove("d-none");
  }
});

}); //end event listener
</script>

<!-- filter sosial -->
<script>
  const sosial = document.getElementById('button_sosial');

sosial.addEventListener('click', function() {
const filter_category = this.value.toLowerCase();
items.forEach(function(item) {
  const filterData = item.getAttribute('data-filter').toLowerCase();
  if (filterData.includes(filter_category)) {
    item.style.display = 'block';
    categoryspace.classList.add("d-none");
  } else {
    item.style.display = 'none';
    categoryspace.classList.remove("d-none");
  }
});

}); //end event listener

</script>

</body>
</html><?php /**PATH E:\Coding\We-Care\resources\views/landing/home.blade.php ENDPATH**/ ?>