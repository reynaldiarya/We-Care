
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/assets/extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" href="/assets/css/pages/datatables.css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Daftar Campaign</h3>
                </div>
            </div>
        </div>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible show fade" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger alert-dismissible show fade" role="alert">
                    <?php echo e($error); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <!-- Basic Tables start -->
        <section class="section">
            <div class="card">
                <div class="card-header d-flex justify-content-between">Daftar Campaign
                </div>
                <div class="card-body">
                    <table class="table" id="table1">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Judul</th>
                                <th>Kategori</th>
                                <th>Penggalang Dana</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Akhir</th>
                                <th>Target</th>
                                <th>Status</th>
                                <th>Tindakan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 0 ?>
                            <?php $__currentLoopData = $campaign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $i++ ?>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($item->judul_campaign); ?></td>
                                    <td><?php echo e($item->category->nama_kategori); ?></td>
                                    <td><?php echo e($item->user->name); ?></td>
                                    <td><?php echo e($item->tgl_mulai_campaign); ?></td>
                                    <td><?php echo e($item->tgl_akhir_campaign); ?></td>
                                    <td><?php echo e($item->target_campaign); ?></td>
                                    <td>
                                        <?php if($item->status_campaign == 0): ?>
                                            Pending
                                        <?php endif; ?>
                                        <?php if($item->status_campaign == 1): ?>
                                            Disetujui
                                        <?php endif; ?>
                                        <?php if($item->status_campaign == 2): ?>
                                            Ditolak
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" class="btn" data-bs-toggle="modal"
                                            data-bs-target="#tes<?php echo e($item->id); ?>">
                                            <i class="bi bi-pencil-fill"></i>
                                        </button>
                                    </td>
                                </tr>
                                <div class="modal fade text-left" id="tes<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel33" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel33">
                                                    Edit Status
                                                </h4>
                                                <button type="button" class="close" data-bs-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="#">
                                                <div class="modal-body">
                                                    <label>Edit Status</label>
                                                    <div class="form-group">
                                                        <select class="form-select" id="basicSelect">
                                                            <option disabled selected value="<?php echo e($item->status_campaign); ?>">
                                                                <?php if($item->status_campaign == 0): ?>
                                                                    Pending
                                                                <?php endif; ?>
                                                                <?php if($item->status_campaign == 1): ?>
                                                                    Disetujui
                                                                <?php endif; ?>
                                                                <?php if($item->status_campaign == 2): ?>
                                                                    Ditolak
                                                                <?php endif; ?>
                                                            </option>
                                                            <option value="0">Pending</option>
                                                            <option value="1">Disetujui</option>
                                                            <option value="2">Ditolak</option>
                                                        </select>

                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-light-secondary"
                                                        data-bs-dismiss="modal">
                                                        <i class="bx bx-x d-block d-sm-none"></i>
                                                        <span class="d-none d-sm-block">Batal</span>
                                                    </button>
                                                    <button type="button" class="btn btn-primary ml-1"
                                                        data-bs-dismiss="modal">
                                                        <i class="bx bx-check d-block d-sm-none"></i>
                                                        <span class="d-none d-sm-block">Ubah</span>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </section>
        <!-- Basic Tables end -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="/assets/extensions/jquery/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>
    <script src="/assets/js/pages/datatables.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding\We-Care\resources\views/admin/campaign.blade.php ENDPATH**/ ?>