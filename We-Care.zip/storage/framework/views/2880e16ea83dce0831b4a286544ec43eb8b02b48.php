<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/assets/css/main/app.css" />
    <link rel="stylesheet" href="/assets/css/pages/error.css" />
    <link rel="shortcut icon" href="/assets/images/logo/favicon.ico" type="image/x-icon">
</head>

<body>
    <?php echo $__env->yieldContent('error'); ?>
</body>

</html>
<?php /**PATH E:\Coding\We-Care\resources\views/errors/errors.blade.php ENDPATH**/ ?>