<?php echo e($slot); ?>

<?php /**PATH E:\Coding\We-Care\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>